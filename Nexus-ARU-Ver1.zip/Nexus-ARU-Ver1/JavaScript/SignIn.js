import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-app.js';
import { getFirestore, collection, getDocs, getCountFromServer} from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-firestore.js';

const firebaseConfig = 
{
 apiKey: "AIzaSyDdWJ3JPey-4Vwm-sfPbZJ--7qqZFsl1IQ",
 authDomain: "nexus-aru.firebaseapp.com",
 projectId: "nexus-aru",
 storageBucket: "nexus-aru.appspot.com",
 messagingSenderId: "473949076344",
 appId: "1:473949076344:web:d3485fb2eb4d080299268d",
 measurementId: "G-8E0DB8CRLH"
};

const firebaseapp = initializeApp(firebaseConfig);
const db = getFirestore(firebaseapp);
const usersRef = collection(db, "Users");

const Login = document.getElementById("Login");
Login.addEventListener("click", function login()
{
 const MoodleID = document.getElementById('MID').value;
 const Password = document.getElementById('Password').value;
 console.log(MoodleID, Password);
 verify(MoodleID, Password);
});

function verify(MID, Password)
{
 let userExists = false;
 getDocs(usersRef)
 .then((querySnapshot) =>
  {
   querySnapshot.forEach((doc) => 
   {
    if(MID == doc.data().MID)
    {
     userExists =true;
     console.log("Match found. Checking password")
     if(Password == doc.data().Password)
     {
      // alert("Login Successful");
      checkType(doc.data());
     }
     else
     {console.log("Incorrect Password!!!"); alert("Incorrect password!!!");}
    }
    });

   if(!userExists)
   {alert("No such user exists.");}
   
  }).catch((error) =>
  {console.error("Error getting documents:", error);});
}

function checkType(user)
{
 if(user.Type == "Student")
 {
  console.log("Type: Student");
  localStorage.setItem('userData', JSON.stringify(user));
  window.location.href = 'Homepage.html';
 }
 else
 {
  if(user.Type == "Admin")
  {
   console.log("Type: Admin");
   localStorage.setItem('userData', JSON.stringify(user));
   window.location.href = 'Homepage.html';
  }
  else
  {
   if(user.Type == "Teacher")
   {
    console.log("Type: Teacher");
    localStorage.setItem('userData', JSON.stringify(user));
    window.location.href = 'Homepage.html';
   }
   else
   {alert("Invalid usertype");}
  }
 }
}