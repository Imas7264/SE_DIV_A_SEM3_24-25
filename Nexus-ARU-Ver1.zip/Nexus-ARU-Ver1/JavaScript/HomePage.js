const userData = JSON.parse(localStorage.getItem('userData'));

if(userData)
{
 const usernameElement = document.getElementById('userDataDisplay');
 usernameElement.textContent = `${userData.Name} / ${userData.MID} / ${userData.Type}`
}
else
{console.log("User data not found.");}

import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-app.js';
import { getFirestore, collection, getDocs, getCountFromServer} from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-firestore.js';

const firebaseConfig = 
{
 apiKey: "AIzaSyDdWJ3JPey-4Vwm-sfPbZJ--7qqZFsl1IQ",
 authDomain: "nexus-aru.firebaseapp.com",
 projectId: "nexus-aru",
 storageBucket: "nexus-aru.appspot.com",
 messagingSenderId: "473949076344",
 appId: "1:473949076344:web:d3485fb2eb4d080299268d",
 measurementId: "G-8E0DB8CRLH"
};

const firebaseapp = initializeApp(firebaseConfig);
const db = getFirestore(firebaseapp);
const usersRef = collection(db, "Users");

// Function to populate the table
function populateTable() {
  getDocs(usersRef)
    .then((querySnapshot) => {
      const tableBody = document.getElementById("tableBody");
      tableBody.innerHTML = ""; // Clear existing data

      querySnapshot.forEach((doc) => {
        const row = document.createElement("tr");
        const recipient = doc.data();
        row.innerHTML = `
          <td><button class="table-button" id="Recipient"><i class="fa-solid fa-user"></i>${recipient.Name} / ${recipient.MID} / ${recipient.Type}</button></td>
        `;
        tableBody.appendChild(row);
      });
    })
    .catch((error) => {
      console.error("Error getting documents:", error);
    });
}

// Call the function to populate the table on page load
populateTable();
